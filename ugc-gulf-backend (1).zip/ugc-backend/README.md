# UGC Gulf — Backend

Real Express API + Postgres schema for the dual-sided UGC marketplace: auth-gated
routes backed by Supabase, and a working Stripe Connect escrow flow (fund → hold →
release, with disputes/refunds). Nothing here is a mock — every route hits a real
database or the real Stripe API once you supply your own keys.

## What's real vs. what needs a third-party account

| Capability | Status |
|---|---|
| Auth, database, RLS | Real — needs a free Supabase project |
| Escrow (fund/release/refund/express payout) | Real Stripe Connect code — needs a Stripe account (test mode is fine) |
| Contracts, messaging, reviews, disputes, admin panel, agencies, brief/application flow | Real — runs on Supabase, no extra account needed |
| AI proposal assistant (`POST /api/applications/draft-pitch`) | Real OpenAI call — needs `OPENAI_API_KEY`, returns `501` until set |
| WhatsApp deadline nudges / SendGrid emails | Not wired up — `.env.example` has placeholders; see "Optional integrations" below |
| GitHub OAuth | Out of scope — that's for logging into Bubble itself, unrelated to this app |

## 1. Set up Supabase (5 min)

1. Create a project at supabase.com.
2. Go to the SQL Editor and run the entire contents of `supabase/schema.sql`. This creates every table, enum, and Row Level Security policy.
3. Go to Project Settings → API and copy:
   - `Project URL` → `SUPABASE_URL`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (server-only, never ship this to the frontend)
   - `anon` key → `SUPABASE_ANON_KEY`
4. In Authentication → Providers, enable whichever sign-in methods you want (phone OTP is a good fit for MENA, per the original app spec).
5. **Important:** after a user signs up via Supabase Auth, insert a matching row into `profiles` with their chosen `role` (creator/brand/agency) — the frontend's signup flow should call `PATCH /api/profiles/me` right after sign-up to set this. `requireAuth` will 403 any user without a profile row.

## 2. Set up Stripe (5 min)

1. Create a Stripe account (test mode is fine to start).
2. Developers → API keys → copy the secret key into `STRIPE_SECRET_KEY`.
3. Enable **Stripe Connect** (Connect → Get started → Express accounts).
4. For webhooks: run `stripe listen --forward-to localhost:8787/api/webhooks/stripe` locally (Stripe CLI), or add a real webhook endpoint in the Dashboard pointing at `https://your-domain.com/api/webhooks/stripe` once deployed, subscribed to at least:
   - `payment_intent.succeeded`
   - `account.updated`
   - `charge.refunded`
5. Copy the resulting signing secret into `STRIPE_WEBHOOK_SECRET`.

## 3. Run it

```bash
npm install
cp .env.example .env   # fill in the values from steps 1-2
npm run dev             # http://localhost:8787
```

`GET /health` should return `{ ok: true }`.

## 4. Deploy

Any Node host works (Railway, Render, Fly.io). Two things to remember:
- Set every variable from `.env.example` in your host's environment settings.
- Point the Stripe webhook endpoint at your deployed URL, not localhost.

## Escrow flow, end to end

1. Brand posts a brief → `POST /api/briefs`
2. Creator applies → `POST /api/applications`
3. Brand accepts → `POST /api/collaborations` (creates the escrow record)
4. Brand funds it → `POST /api/collaborations/:id/fund` → returns a Stripe `client_secret`; confirm it client-side with Stripe Elements/Payment Element
5. Stripe confirms the charge → webhook flips status to `funded`
6. Creator submits the draft → `POST /api/collaborations/:id/submit`
7. Brand requests changes (up to `max_revisions`) or approves
8. Approve → `POST /api/collaborations/:id/approve` → real `stripe.transfers.create` moves funds (minus platform commission) to the creator's connected Stripe account
9. Either side can dispute instead of approving → admin resolves via `POST /api/admin/disputes/:id/resolve` with `refund` or `release`

Creators must complete `POST /api/payments/connect/onboard` (Stripe Express onboarding) before step 8 will succeed — this is enforced in `releaseEscrowToCreator`.

## Optional integrations (not wired up, but the schema/hooks are ready)

- **SendGrid** — hook into the `notifications` table inserts (search each route for `.from('notifications').insert`) to also fire an email.
- **Twilio WhatsApp** — feature 67 (delivery deadline nudges) needs a scheduled job (cron / Supabase Edge Function on a timer) querying `collaborations` where `submitted_at` is null and the brief deadline is within 24h, then calling the Twilio API. Not included here since it needs a scheduler, not just an endpoint.
- **OpenAI** — already wired for the pitch assistant; the same pattern extends to the "AI Brief & Script Localizer" (Arabic dialects) feature if you want it — add a `POST /api/briefs/:id/localize` route calling the same `fetch('https://api.openai.com/...')` pattern used in `applications.routes.js`.

## Endpoint reference (grouped by the original feature list)

- **Onboarding/verification** — `PATCH /api/profiles/me`, `/me/shipping-address`, `/me/business-license`, admin `/api/admin/users/:id/verify`, `/verify-license`
- **Opportunity hub** — `GET /api/profiles` (creator/agency search), `GET /api/briefs`, `POST /api/briefs`, `GET /api/briefs/estimate`
- **Workspace** — `POST /api/collaborations`, `/submit`, `/request-revision`, `/comments` (frame-by-frame feedback), `/milestones/:index/complete`
- **Messaging** — `POST /api/messages/threads`, `/threads/:id/messages`, `/threads/:id/read`
- **Financial/escrow** — `POST /api/collaborations/:id/fund`, `/approve`, `/dispute`; `POST /api/payments/connect/onboard`, `/express-payout`
- **Analytics/licensing** — packages/usage-rights live on `packages.usage_rights`; ledger via `GET /api/admin/ledger`
- **Admin** — everything under `/api/admin/*`
- **Gulf localization** — `currency` enum on briefs/packages/transactions, `country`/`dialect` fields, `business_license_*` fields
- **Monetization** — `POST /api/briefs/:id/feature` (featured brief), `is_pro_member` flag, `POST /api/payments/express-payout`
- **AI matching** — `match_score` on applications (`computeMatchScore`), tiered shortlist via `GET /api/applications/brief/:briefId`, `POST /api/applications/draft-pitch`
