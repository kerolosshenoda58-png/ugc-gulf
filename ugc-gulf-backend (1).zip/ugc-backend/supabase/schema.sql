-- ============================================================================
-- UGC Gulf Platform — Full Postgres Schema (Supabase)
-- Run this in the Supabase SQL editor, or via `supabase db push`.
-- Assumes Supabase Auth (auth.users) is already enabled.
-- ============================================================================

create extension if not exists "uuid-ossp";

-- ─── Enums ──────────────────────────────────────────────────────────────────
create type user_role as enum ('creator', 'brand', 'agency', 'admin');
create type brief_status as enum ('open', 'in_review', 'closed', 'cancelled');
create type application_status as enum ('pending', 'accepted', 'rejected', 'withdrawn');
create type collab_status as enum (
  'pending_funding', 'funded', 'in_progress', 'submitted',
  'revision_requested', 'approved', 'released', 'disputed', 'refunded', 'cancelled'
);
create type contract_status as enum ('draft', 'sent', 'brand_signed', 'creator_signed', 'fully_signed');
create type dispute_status as enum ('open', 'under_review', 'resolved_refund', 'resolved_release', 'closed');
create type currency_code as enum ('USD', 'AED', 'SAR', 'KWD', 'QAR');

-- ─── Profiles (extends auth.users) ─────────────────────────────────────────
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null default 'creator',
  full_name text,
  handle text unique,
  bio text,
  avatar_url text,
  country text,
  city text,
  language_pref text default 'en',
  is_verified boolean default false,
  availability_status text default 'available', -- available | booked | on_break

  -- Creator-specific
  niche text[] default '{}',
  skills text[] default '{}',
  platforms text[] default '{}',
  followers_count integer default 0,
  rating_avg numeric(3,2) default 0,
  review_count integer default 0,
  xp_points integer default 0,
  response_time_hours numeric default 24,
  stripe_connect_account_id text,           -- Stripe Express account for payouts
  stripe_connect_onboarded boolean default false,

  -- Brand-specific
  company_name text,
  industry text,
  website text,
  business_license_url text,                -- KSA CR / UAE Trade License upload
  business_license_verified boolean default false,
  stripe_customer_id text,                  -- Stripe customer for charging escrow

  -- Agency-specific
  employee_count text,
  parent_agency_id uuid references profiles(id), -- for multi-seat sub-accounts

  is_pro_member boolean default false,       -- Creator "Pro" badge subscription
  is_banned boolean default false,
  shipping_address jsonb,                    -- Feature 6: product-gifting address vault

  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_profiles_role on profiles(role);
create index idx_profiles_country on profiles(country);

-- ─── Campaign Briefs (posted by Brands) ────────────────────────────────────
create table briefs (
  id uuid primary key default uuid_generate_v4(),
  brand_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text,
  category text,                             -- Beauty / Tech / Fashion / Fitness / Food ...
  content_goal text,                         -- Organic | Paid Ad | Whitelisting
  platforms text[] default '{}',
  deliverables_count integer default 1,
  budget numeric(10,2) not null,
  currency currency_code default 'USD',
  country text,                              -- target Gulf country
  dialect text,                              -- Khaliji | Egyptian | Fusha ...
  deadline date,
  status brief_status default 'open',
  is_featured boolean default false,         -- paid "Featured Brief" upgrade
  featured_until timestamptz,
  requirements_file_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_briefs_status on briefs(status);
create index idx_briefs_category on briefs(category);
create index idx_briefs_country on briefs(country);

-- ─── Creator Packages (rate cards) ──────────────────────────────────────────
create table packages (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references profiles(id) on delete cascade,
  name text not null,                        -- Basic / Standard / Premium
  price numeric(10,2) not null,
  currency currency_code default 'USD',
  delivery_days integer default 3,
  deliverables text,
  usage_rights text default '30_days',       -- 30_days | 1_year | forever
  created_at timestamptz default now()
);

-- ─── Portfolio items ────────────────────────────────────────────────────────
create table portfolio_items (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references profiles(id) on delete cascade,
  media_url text not null,
  media_type text default 'video',           -- video | image
  caption text,
  created_at timestamptz default now()
);

-- ─── Applications (Creator applies to Brief) ───────────────────────────────
create table applications (
  id uuid primary key default uuid_generate_v4(),
  brief_id uuid not null references briefs(id) on delete cascade,
  creator_id uuid not null references profiles(id) on delete cascade,
  package_id uuid references packages(id),
  pitch text,
  ai_generated_pitch boolean default false,
  match_score numeric(5,2),                  -- Smart Match Score (AI compatibility %)
  status application_status default 'pending',
  created_at timestamptz default now(),
  unique (brief_id, creator_id)
);

create index idx_applications_brief on applications(brief_id);
create index idx_applications_creator on applications(creator_id);

-- ─── Collaborations (the escrow-backed "order") ────────────────────────────
create table collaborations (
  id uuid primary key default uuid_generate_v4(),
  brief_id uuid references briefs(id),
  application_id uuid references applications(id),
  brand_id uuid not null references profiles(id),
  creator_id uuid not null references profiles(id),

  amount numeric(10,2) not null,             -- total escrow amount
  currency currency_code default 'USD',
  platform_fee_pct numeric(5,2) default 10.0,
  platform_fee_amount numeric(10,2),
  creator_payout_amount numeric(10,2),

  status collab_status default 'pending_funding',

  stripe_payment_intent_id text,
  stripe_transfer_id text,

  milestones jsonb default '[]',             -- [{label, pct, released:false}]
  revision_count integer default 0,
  max_revisions integer default 2,
  submission_url text,
  raw_files_url text,

  funded_at timestamptz,
  submitted_at timestamptz,
  approved_at timestamptz,
  released_at timestamptz,

  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_collab_brand on collaborations(brand_id);
create index idx_collab_creator on collaborations(creator_id);
create index idx_collab_status on collaborations(status);

-- ─── Video review comments (frame-by-frame feedback) ───────────────────────
create table video_comments (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid not null references collaborations(id) on delete cascade,
  author_id uuid not null references profiles(id),
  timestamp_ms integer not null,
  comment text not null,
  resolved boolean default false,
  created_at timestamptz default now()
);

-- ─── Contracts ──────────────────────────────────────────────────────────────
create table contracts (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid references collaborations(id) on delete cascade,
  template_type text not null,               -- Standard UGC / Multi-Video / Ambassador / License / Review / Whitelisting
  content text,                              -- rendered contract text/HTML
  status contract_status default 'draft',
  brand_signed_at timestamptz,
  creator_signed_at timestamptz,
  created_at timestamptz default now()
);

-- ─── Messages ───────────────────────────────────────────────────────────────
create table message_threads (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid references collaborations(id),
  participant_ids uuid[] not null,
  created_at timestamptz default now()
);

create table messages (
  id uuid primary key default uuid_generate_v4(),
  thread_id uuid not null references message_threads(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  content text,
  attachment_url text,
  read_by uuid[] default '{}',
  created_at timestamptz default now()
);

create index idx_messages_thread on messages(thread_id);

-- ─── Reviews ────────────────────────────────────────────────────────────────
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid references collaborations(id),
  reviewer_id uuid not null references profiles(id),
  reviewee_id uuid not null references profiles(id),
  rating integer check (rating between 1 and 5),
  content text,
  is_flagged boolean default false,
  created_at timestamptz default now()
);

create index idx_reviews_reviewee on reviews(reviewee_id);

-- ─── Transactions ledger (platform-wide financial audit trail) ────────────
create table transactions (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid references collaborations(id),
  type text not null,                        -- escrow_fund | platform_fee | creator_payout | refund | express_payout_fee
  amount numeric(10,2) not null,
  currency currency_code default 'USD',
  stripe_reference text,
  status text default 'completed',
  created_at timestamptz default now()
);

create index idx_transactions_collab on transactions(collaboration_id);

-- ─── Disputes ───────────────────────────────────────────────────────────────
create table disputes (
  id uuid primary key default uuid_generate_v4(),
  collaboration_id uuid not null references collaborations(id),
  raised_by uuid not null references profiles(id),
  reason text not null,
  status dispute_status default 'open',
  admin_notes text,
  resolved_by uuid references profiles(id),
  resolved_at timestamptz,
  created_at timestamptz default now()
);

-- ─── Notifications ──────────────────────────────────────────────────────────
create table notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,                        -- new_application | escrow_funded | draft_submitted | approved | message | deadline_reminder
  payload jsonb default '{}',
  read boolean default false,
  created_at timestamptz default now()
);

create index idx_notifications_user on notifications(user_id, read);

-- ─── Saved searches & alerts ────────────────────────────────────────────────
create table saved_searches (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  filters jsonb not null,
  created_at timestamptz default now()
);

-- ─── Platform settings (admin-controlled) ──────────────────────────────────
create table platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz default now()
);

insert into platform_settings (key, value) values
  ('commission_pct', '10'),
  ('express_payout_fee_pct', '1.5'),
  ('announcement', '{"active": false, "text": ""}');

-- ============================================================================
-- Row Level Security
-- ============================================================================
alter table profiles enable row level security;
alter table briefs enable row level security;
alter table packages enable row level security;
alter table portfolio_items enable row level security;
alter table applications enable row level security;
alter table collaborations enable row level security;
alter table video_comments enable row level security;
alter table contracts enable row level security;
alter table message_threads enable row level security;
alter table messages enable row level security;
alter table reviews enable row level security;
alter table transactions enable row level security;
alter table disputes enable row level security;
alter table notifications enable row level security;
alter table saved_searches enable row level security;

-- Helper: is the current user an admin?
create or replace function is_admin() returns boolean as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$ language sql security definer;

-- Profiles: public read (directory), owner write, admin full access
create policy "profiles_public_read" on profiles for select using (true);
create policy "profiles_owner_write" on profiles for update using (auth.uid() = id);
create policy "profiles_owner_insert" on profiles for insert with check (auth.uid() = id);
create policy "profiles_admin_all" on profiles for all using (is_admin());

-- Briefs: public read of open briefs, brand owns writes
create policy "briefs_public_read" on briefs for select using (status = 'open' or brand_id = auth.uid() or is_admin());
create policy "briefs_brand_write" on briefs for insert with check (brand_id = auth.uid());
create policy "briefs_brand_update" on briefs for update using (brand_id = auth.uid() or is_admin());

-- Packages / portfolio: public read, creator-owned write
create policy "packages_public_read" on packages for select using (true);
create policy "packages_owner_write" on packages for all using (creator_id = auth.uid());
create policy "portfolio_public_read" on portfolio_items for select using (true);
create policy "portfolio_owner_write" on portfolio_items for all using (creator_id = auth.uid());

-- Applications: visible to the applicant + the brief owner
create policy "applications_visible" on applications for select
  using (creator_id = auth.uid() or is_admin() or
         exists (select 1 from briefs b where b.id = brief_id and b.brand_id = auth.uid()));
create policy "applications_creator_insert" on applications for insert with check (creator_id = auth.uid());
create policy "applications_update" on applications for update
  using (creator_id = auth.uid() or is_admin() or
         exists (select 1 from briefs b where b.id = brief_id and b.brand_id = auth.uid()));

-- Collaborations: visible only to the two parties + admin
create policy "collab_visible" on collaborations for select
  using (brand_id = auth.uid() or creator_id = auth.uid() or is_admin());
create policy "collab_update" on collaborations for update
  using (brand_id = auth.uid() or creator_id = auth.uid() or is_admin());
create policy "collab_insert" on collaborations for insert with check (brand_id = auth.uid());

-- Video comments: parties on the collaboration only
create policy "video_comments_visible" on video_comments for select
  using (exists (select 1 from collaborations c where c.id = collaboration_id
                 and (c.brand_id = auth.uid() or c.creator_id = auth.uid())) or is_admin());
create policy "video_comments_insert" on video_comments for insert
  with check (exists (select 1 from collaborations c where c.id = collaboration_id
                 and (c.brand_id = auth.uid() or c.creator_id = auth.uid())));

-- Contracts: parties on the collaboration only
create policy "contracts_visible" on contracts for select
  using (exists (select 1 from collaborations c where c.id = collaboration_id
                 and (c.brand_id = auth.uid() or c.creator_id = auth.uid())) or is_admin());

-- Messages: only thread participants
create policy "threads_visible" on message_threads for select using (auth.uid() = any(participant_ids) or is_admin());
create policy "messages_visible" on messages for select
  using (exists (select 1 from message_threads t where t.id = thread_id and auth.uid() = any(t.participant_ids)) or is_admin());
create policy "messages_insert" on messages for insert
  with check (sender_id = auth.uid() and
              exists (select 1 from message_threads t where t.id = thread_id and auth.uid() = any(t.participant_ids)));

-- Reviews: public read, only collaboration parties can write
create policy "reviews_public_read" on reviews for select using (not is_flagged or is_admin());
create policy "reviews_insert" on reviews for insert with check (reviewer_id = auth.uid());
create policy "reviews_admin_moderate" on reviews for update using (is_admin());

-- Transactions / disputes: parties + admin only
create policy "transactions_visible" on transactions for select
  using (exists (select 1 from collaborations c where c.id = collaboration_id
                 and (c.brand_id = auth.uid() or c.creator_id = auth.uid())) or is_admin());
create policy "disputes_visible" on disputes for select
  using (raised_by = auth.uid() or is_admin() or
         exists (select 1 from collaborations c where c.id = collaboration_id
                 and (c.brand_id = auth.uid() or c.creator_id = auth.uid())));
create policy "disputes_insert" on disputes for insert with check (raised_by = auth.uid());
create policy "disputes_admin_update" on disputes for update using (is_admin());

-- Notifications: owner only
create policy "notifications_owner" on notifications for select using (user_id = auth.uid());
create policy "notifications_owner_update" on notifications for update using (user_id = auth.uid());

-- Saved searches: owner only
create policy "saved_searches_owner" on saved_searches for all using (user_id = auth.uid());
