import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

import webhooksRoutes from './routes/webhooks.routes.js';
import profilesRoutes from './routes/profiles.routes.js';
import briefsRoutes from './routes/briefs.routes.js';
import applicationsRoutes from './routes/applications.routes.js';
import collaborationsRoutes from './routes/collaborations.routes.js';
import paymentsRoutes from './routes/payments.routes.js';
import messagesRoutes from './routes/messages.routes.js';
import reviewsRoutes from './routes/reviews.routes.js';
import contractsRoutes from './routes/contracts.routes.js';
import agenciesRoutes from './routes/agencies.routes.js';
import adminRoutes from './routes/admin.routes.js';

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));

// IMPORTANT: the Stripe webhook needs the raw request body to verify the signature,
// so it must be mounted BEFORE express.json() and must not be JSON-parsed.
app.use('/api/webhooks', express.raw({ type: 'application/json' }), webhooksRoutes);

app.use(express.json({ limit: '2mb' }));

app.get('/health', (req, res) => res.json({ ok: true, service: 'ugc-gulf-backend' }));

app.use('/api/profiles', profilesRoutes);
app.use('/api/briefs', briefsRoutes);
app.use('/api/applications', applicationsRoutes);
app.use('/api/collaborations', collaborationsRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/messages', messagesRoutes);
app.use('/api/reviews', reviewsRoutes);
app.use('/api/contracts', contractsRoutes);
app.use('/api/agencies', agenciesRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`UGC Gulf backend listening on :${PORT}`));
