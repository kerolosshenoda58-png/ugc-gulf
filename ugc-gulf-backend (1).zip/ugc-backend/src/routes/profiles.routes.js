import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

// GET /api/profiles/me
router.get('/me', requireAuth, (req, res) => res.json(req.profile));

// PATCH /api/profiles/me — Feature 1 (onboarding funnel writes here), Feature 13 (availability toggle)
router.patch('/me', requireAuth, async (req, res) => {
  const allowed = [
    'full_name', 'handle', 'bio', 'avatar_url', 'country', 'city', 'language_pref',
    'niche', 'skills', 'platforms', 'availability_status',
    'company_name', 'industry', 'website', 'business_license_url',
    'employee_count',
  ];
  const updates = Object.fromEntries(Object.entries(req.body).filter(([k]) => allowed.includes(k)));
  updates.updated_at = new Date().toISOString();

  const { data, error } = await supabaseAdmin.from('profiles').update(updates).eq('id', req.profile.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 6 — encrypted-at-rest delivery address vault (stored as a private JSONB column
// via a dedicated table would be ideal at scale; profiles.metadata keeps this MVP simple)
router.put('/me/shipping-address', requireAuth, requireRole('creator'), async (req, res) => {
  const { line1, city, country, postal_code, phone } = req.body;
  const { data, error } = await supabaseAdmin
    .from('profiles')
    .update({ shipping_address: { line1, city, country, postal_code, phone } })
    .eq('id', req.profile.id)
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 52 — GCC business license upload/verification flag (file itself goes to Supabase Storage
// from the frontend; this just records the resulting URL and resets the verified flag for admin review)
router.put('/me/business-license', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'url is required' });
  const { data, error } = await supabaseAdmin
    .from('profiles')
    .update({ business_license_url: url, business_license_verified: false })
    .eq('id', req.profile.id)
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// GET /api/profiles?role=creator&country=UAE&niche=Beauty&search=...
// Feature 8 — Dynamic Multi-Filter Search Engine
router.get('/', async (req, res) => {
  const { role = 'creator', country, niche, skill, search, sort = '-rating_avg', limit = 50 } = req.query;

  let query = supabaseAdmin.from('profiles').select('*').eq('role', role);
  if (country) query = query.eq('country', country);
  if (niche) query = query.contains('niche', [niche]);
  if (skill) query = query.contains('skills', [skill]);
  if (search) query = query.or(`full_name.ilike.%${search}%,bio.ilike.%${search}%,company_name.ilike.%${search}%`);

  const [col, dir] = sort.startsWith('-') ? [sort.slice(1), false] : [sort, true];
  query = query.order(col, { ascending: dir }).limit(Number(limit));

  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.get('/:id', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').select('*').eq('id', req.params.id).single();
  if (error) return res.status(404).json({ error: 'Profile not found' });
  res.json(data);
});

// Feature 32 — creator rate cards
router.get('/:id/packages', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('packages').select('*').eq('creator_id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.post('/me/packages', requireAuth, requireRole('creator'), async (req, res) => {
  const { name, price, currency, delivery_days, deliverables, usage_rights } = req.body;
  const { data, error } = await supabaseAdmin.from('packages')
    .insert({ creator_id: req.profile.id, name, price, currency, delivery_days, deliverables, usage_rights })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// Feature 3 — Dynamic Creator Media Kit (aggregated public view: profile + packages + portfolio + reviews)
router.get('/:id/media-kit', async (req, res) => {
  const id = req.params.id;
  const [{ data: profile }, { data: packages }, { data: portfolio }, { data: reviews }] = await Promise.all([
    supabaseAdmin.from('profiles').select('*').eq('id', id).single(),
    supabaseAdmin.from('packages').select('*').eq('creator_id', id),
    supabaseAdmin.from('portfolio_items').select('*').eq('creator_id', id),
    supabaseAdmin.from('reviews').select('*').eq('reviewee_id', id).eq('is_flagged', false),
  ]);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });
  res.json({ profile, packages, portfolio, reviews });
});

export default router;
