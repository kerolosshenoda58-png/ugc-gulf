import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

export const CONTRACT_TEMPLATES = {
  standard_ugc: 'Standard UGC Video Agreement',
  multi_video: 'Multi-Video Campaign Contract',
  ambassador: 'Brand Ambassador Agreement',
  one_time_license: 'One-Time Usage License',
  product_review: 'Product Review Agreement',
  whitelisting: 'Whitelisting / Spark Ads Addendum',
};

function renderContract(templateType, collab, brand, creator) {
  const title = CONTRACT_TEMPLATES[templateType] || 'UGC Agreement';
  return `${title}\n\nBetween ${brand.company_name || brand.full_name} ("Brand") and ${creator.full_name} ("Creator").\n` +
    `Total value: ${collab.amount} ${collab.currency}. Deliverables per brief. Payment held in escrow and released on approval.\n` +
    `Revisions included: ${collab.max_revisions}. Governed by platform Terms of Service.`;
}

// Feature 19 — Custom Legal Contract Generator, auto-filled from the collaboration
router.post('/', requireAuth, async (req, res) => {
  const { collaboration_id, template_type } = req.body;
  const { data: collab } = await supabaseAdmin.from('collaborations').select('*').eq('id', collaboration_id).single();
  if (!collab) return res.status(404).json({ error: 'Collaboration not found' });
  if (![collab.brand_id, collab.creator_id].includes(req.profile.id)) return res.status(403).json({ error: 'Forbidden' });

  const [{ data: brand }, { data: creator }] = await Promise.all([
    supabaseAdmin.from('profiles').select('*').eq('id', collab.brand_id).single(),
    supabaseAdmin.from('profiles').select('*').eq('id', collab.creator_id).single(),
  ]);

  const content = renderContract(template_type, collab, brand, creator);
  const { data, error } = await supabaseAdmin.from('contracts')
    .insert({ collaboration_id, template_type, content, status: 'sent' }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

router.post('/:id/sign', requireAuth, async (req, res) => {
  const { data: contract } = await supabaseAdmin.from('contracts').select('*, collaboration:collaborations(*)').eq('id', req.params.id).single();
  if (!contract) return res.status(404).json({ error: 'Not found' });

  const isBrand = req.profile.id === contract.collaboration.brand_id;
  const isCreator = req.profile.id === contract.collaboration.creator_id;
  if (!isBrand && !isCreator) return res.status(403).json({ error: 'Forbidden' });

  const patch = isBrand ? { brand_signed_at: new Date().toISOString() } : { creator_signed_at: new Date().toISOString() };
  const willBeFullySigned = (isBrand ? true : !!contract.brand_signed_at) && (isCreator ? true : !!contract.creator_signed_at);
  patch.status = willBeFullySigned ? 'fully_signed' : isBrand ? 'brand_signed' : 'creator_signed';

  const { data, error } = await supabaseAdmin.from('contracts').update(patch).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.get('/collaboration/:collabId', requireAuth, async (req, res) => {
  const { data, error } = await supabaseAdmin.from('contracts').select('*').eq('collaboration_id', req.params.collabId);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
