import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

router.get('/', async (req, res) => {
  const { country, search, limit = 50 } = req.query;
  let query = supabaseAdmin.from('profiles').select('*').eq('role', 'agency');
  if (country) query = query.eq('country', country);
  if (search) query = query.or(`full_name.ilike.%${search}%,company_name.ilike.%${search}%`);
  query = query.order('rating_avg', { ascending: false }).limit(Number(limit));

  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 5 — Multi-Brand Enterprise Portals: create a sub-brand under an agency's master billing account
router.post('/sub-accounts', requireAuth, requireRole('agency'), async (req, res) => {
  const { email, full_name, company_name } = req.body;

  const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
    email, email_confirm: true, user_metadata: { invited_by_agency: req.profile.id },
  });
  if (authError) return res.status(400).json({ error: authError.message });

  const { data, error } = await supabaseAdmin.from('profiles').insert({
    id: authUser.user.id, role: 'brand', full_name, company_name, parent_agency_id: req.profile.id,
  }).select().single();
  if (error) return res.status(400).json({ error: error.message });

  res.status(201).json(data);
});

router.get('/sub-accounts', requireAuth, requireRole('agency'), async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').select('*').eq('parent_agency_id', req.profile.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
