import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';
import { createEscrowPaymentIntent, releaseEscrowToCreator, refundEscrow, getOrCreateBrandCustomer } from '../services/stripeService.js';

const router = Router();
const COMMISSION_PCT = Number(process.env.PLATFORM_COMMISSION_PCT || 10);

function requireParty(collab, userId) {
  return collab.brand_id === userId || collab.creator_id === userId;
}

// Brand accepts an application -> creates the collaboration record (status: pending_funding)
// Feature 16 (Kanban board reads this), Feature 35 (milestones)
router.post('/', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { application_id, milestones } = req.body;
  const { data: application } = await supabaseAdmin.from('applications').select('*, brief:briefs(*)').eq('id', application_id).single();
  if (!application) return res.status(404).json({ error: 'Application not found' });
  if (application.brief.brand_id !== req.profile.id) return res.status(403).json({ error: 'Not your brief' });

  const platform_fee_amount = Number((application.brief.budget * (COMMISSION_PCT / 100)).toFixed(2));
  const creator_payout_amount = Number((application.brief.budget - platform_fee_amount).toFixed(2));

  const { data, error } = await supabaseAdmin.from('collaborations').insert({
    brief_id: application.brief_id,
    application_id,
    brand_id: req.profile.id,
    creator_id: application.creator_id,
    amount: application.brief.budget,
    currency: application.brief.currency,
    platform_fee_pct: COMMISSION_PCT,
    platform_fee_amount,
    creator_payout_amount,
    milestones: milestones || [],
  }).select().single();

  if (error) return res.status(400).json({ error: error.message });

  await supabaseAdmin.from('applications').update({ status: 'accepted' }).eq('id', application_id);
  await supabaseAdmin.from('message_threads').insert({ collaboration_id: data.id, participant_ids: [req.profile.id, application.creator_id] });

  res.status(201).json(data);
});

router.get('/', requireAuth, async (req, res) => {
  const col = req.profile.role === 'creator' ? 'creator_id' : 'brand_id';
  const { data, error } = await supabaseAdmin.from('collaborations').select('*').eq(col, req.profile.id).order('created_at', { ascending: false });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.get('/:id', requireAuth, async (req, res) => {
  const { data, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !data) return res.status(404).json({ error: 'Not found' });
  if (!requireParty(data, req.profile.id) && req.profile.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  res.json(data);
});

// Step 1 of escrow — Feature 31: Brand funds the collaboration. Returns a Stripe
// PaymentIntent client_secret; the frontend confirms it with Stripe Elements/Payment Element.
// The `funded` status transition happens in the webhook once Stripe confirms the charge.
router.post('/:id/fund', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { data: collab, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !collab) return res.status(404).json({ error: 'Not found' });
  if (collab.brand_id !== req.profile.id) return res.status(403).json({ error: 'Forbidden' });
  if (collab.status !== 'pending_funding') return res.status(400).json({ error: `Cannot fund a collaboration in status ${collab.status}` });

  try {
    const customerId = await getOrCreateBrandCustomer(req.profile);
    const paymentIntent = await createEscrowPaymentIntent({
      collaborationId: collab.id, amountUsd: collab.amount, brandStripeCustomerId: customerId,
      currency: (collab.currency || 'USD').toLowerCase(),
    });
    res.json({ clientSecret: paymentIntent.client_secret, paymentIntentId: paymentIntent.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feature 20 — creator marks milestone/step complete (e.g. "product arrival acknowledged")
router.post('/:id/milestones/:index/complete', requireAuth, requireRole('creator'), async (req, res) => {
  const { data: collab, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !collab) return res.status(404).json({ error: 'Not found' });
  if (collab.creator_id !== req.profile.id) return res.status(403).json({ error: 'Forbidden' });

  const milestones = [...(collab.milestones || [])];
  const idx = Number(req.params.index);
  if (!milestones[idx]) return res.status(400).json({ error: 'Invalid milestone index' });
  milestones[idx] = { ...milestones[idx], completed: true, completed_at: new Date().toISOString() };

  const { data, error: updateErr } = await supabaseAdmin.from('collaborations').update({ milestones }).eq('id', collab.id).select().single();
  if (updateErr) return res.status(400).json({ error: updateErr.message });
  res.json(data);
});

// Creator uploads the draft
router.post('/:id/submit', requireAuth, requireRole('creator'), async (req, res) => {
  const { submission_url, raw_files_url } = req.body;
  const { data: collab, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !collab) return res.status(404).json({ error: 'Not found' });
  if (collab.creator_id !== req.profile.id) return res.status(403).json({ error: 'Forbidden' });
  if (!['funded', 'revision_requested'].includes(collab.status)) return res.status(400).json({ error: `Cannot submit from status ${collab.status}` });

  const { data, error: updateErr } = await supabaseAdmin.from('collaborations')
    .update({ status: 'submitted', submission_url, raw_files_url, submitted_at: new Date().toISOString() })
    .eq('id', collab.id).select().single();
  if (updateErr) return res.status(400).json({ error: updateErr.message });

  await supabaseAdmin.from('notifications').insert({ user_id: collab.brand_id, type: 'draft_submitted', payload: { collaboration_id: collab.id } });
  res.json(data);
});

// Feature 21 — Revision Cycle Limits Workflow
router.post('/:id/request-revision', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { note } = req.body;
  const { data: collab, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !collab) return res.status(404).json({ error: 'Not found' });
  if (collab.brand_id !== req.profile.id) return res.status(403).json({ error: 'Forbidden' });
  if (collab.revision_count >= collab.max_revisions) {
    return res.status(400).json({ error: `Revision limit reached (${collab.max_revisions}). Approve or open a dispute instead.` });
  }

  const { data, error: updateErr } = await supabaseAdmin.from('collaborations')
    .update({ status: 'revision_requested', revision_count: collab.revision_count + 1 })
    .eq('id', collab.id).select().single();
  if (updateErr) return res.status(400).json({ error: updateErr.message });

  if (note) {
    await supabaseAdmin.from('video_comments').insert({ collaboration_id: collab.id, author_id: req.profile.id, timestamp_ms: 0, comment: note });
  }
  res.json(data);
});

// Feature 18 — Frame-by-Frame Video Feedback
router.post('/:id/comments', requireAuth, async (req, res) => {
  const { timestamp_ms, comment } = req.body;
  const { data: collab } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (!collab || !requireParty(collab, req.profile.id)) return res.status(403).json({ error: 'Forbidden' });

  const { data, error } = await supabaseAdmin.from('video_comments')
    .insert({ collaboration_id: collab.id, author_id: req.profile.id, timestamp_ms, comment }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

router.get('/:id/comments', requireAuth, async (req, res) => {
  const { data: collab } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (!collab || !requireParty(collab, req.profile.id)) return res.status(403).json({ error: 'Forbidden' });
  const { data, error } = await supabaseAdmin.from('video_comments').select('*').eq('collaboration_id', req.params.id).order('timestamp_ms');
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Step 3 of escrow — Feature 31: Brand approves -> releases escrow to the creator
// (minus platform commission, Feature 34) via a real Stripe Transfer.
router.post('/:id/approve', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { data: collab, error } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (error || !collab) return res.status(404).json({ error: 'Not found' });
  if (collab.brand_id !== req.profile.id) return res.status(403).json({ error: 'Forbidden' });
  if (collab.status !== 'submitted') return res.status(400).json({ error: `Cannot approve from status ${collab.status}` });

  try {
    const { transfer, feeCents, payoutCents } = await releaseEscrowToCreator({ collaboration: collab });

    const { data, error: updateErr } = await supabaseAdmin.from('collaborations')
      .update({ status: 'released', approved_at: new Date().toISOString(), released_at: new Date().toISOString(), stripe_transfer_id: transfer.id })
      .eq('id', collab.id).select().single();
    if (updateErr) return res.status(400).json({ error: updateErr.message });

    await supabaseAdmin.from('transactions').insert([
      { collaboration_id: collab.id, type: 'platform_fee', amount: feeCents / 100, currency: collab.currency, stripe_reference: transfer.id },
      { collaboration_id: collab.id, type: 'creator_payout', amount: payoutCents / 100, currency: collab.currency, stripe_reference: transfer.id },
    ]);
    await supabaseAdmin.from('notifications').insert({ user_id: collab.creator_id, type: 'approved', payload: { collaboration_id: collab.id } });

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feature 45/59 — either party raises a dispute instead of approving
router.post('/:id/dispute', requireAuth, async (req, res) => {
  const { reason } = req.body;
  const { data: collab } = await supabaseAdmin.from('collaborations').select('*').eq('id', req.params.id).single();
  if (!collab || !requireParty(collab, req.profile.id)) return res.status(403).json({ error: 'Forbidden' });

  const { data, error } = await supabaseAdmin.from('disputes')
    .insert({ collaboration_id: collab.id, raised_by: req.profile.id, reason }).select().single();
  if (error) return res.status(400).json({ error: error.message });

  await supabaseAdmin.from('collaborations').update({ status: 'disputed' }).eq('id', collab.id);
  res.status(201).json(data);
});

export default router;
