import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

// Feature 30 — Moderation Content Flags: block obvious off-platform payment/contact solicitation
const FLAGGED_PATTERNS = [
  /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/, // phone numbers
  /whatsapp/i, /paypal\.me/i, /venmo/i, /\bcash\s?app\b/i, /wire transfer/i,
  /@gmail\.com|@outlook\.com|@yahoo\.com/i,
];
function flagContent(text = '') {
  return FLAGGED_PATTERNS.some(re => re.test(text));
}

// Feature 24 — pre-deal inbox: create/find a thread not linked to a collaboration yet
router.post('/threads', requireAuth, async (req, res) => {
  const { other_user_id, collaboration_id } = req.body;
  const participant_ids = [req.profile.id, other_user_id].sort();

  const { data: existing } = await supabaseAdmin
    .from('message_threads')
    .select('*')
    .contains('participant_ids', participant_ids)
    .eq('collaboration_id', collaboration_id || null)
    .maybeSingle();

  if (existing) return res.json(existing);

  const { data, error } = await supabaseAdmin.from('message_threads')
    .insert({ participant_ids, collaboration_id: collaboration_id || null }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

router.get('/threads', requireAuth, async (req, res) => {
  const { data, error } = await supabaseAdmin.from('message_threads').select('*').contains('participant_ids', [req.profile.id]);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.get('/threads/:id', requireAuth, async (req, res) => {
  const { data, error } = await supabaseAdmin.from('messages').select('*').eq('thread_id', req.params.id).order('created_at');
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 26/27/30 — send a message (with attachment + moderation flag, but never blocked outright —
// flagged messages are still delivered, just surfaced to admins)
router.post('/threads/:id/messages', requireAuth, async (req, res) => {
  const { content, attachment_url } = req.body;
  const flagged = flagContent(content);

  const { data, error } = await supabaseAdmin.from('messages')
    .insert({ thread_id: req.params.id, sender_id: req.profile.id, content, attachment_url, read_by: [req.profile.id] })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });

  if (flagged) {
    console.warn(`[moderation] possible off-platform solicitation in thread ${req.params.id} by ${req.profile.id}`);
  }

  res.status(201).json({ ...data, flagged });
});

// Feature 28 — read receipts
router.post('/threads/:id/read', requireAuth, async (req, res) => {
  const { data: msgs } = await supabaseAdmin.from('messages').select('id, read_by').eq('thread_id', req.params.id);
  const updates = (msgs || [])
    .filter(m => !m.read_by?.includes(req.profile.id))
    .map(m => supabaseAdmin.from('messages').update({ read_by: [...(m.read_by || []), req.profile.id] }).eq('id', m.id));
  await Promise.all(updates);
  res.json({ marked: updates.length });
});

export default router;
