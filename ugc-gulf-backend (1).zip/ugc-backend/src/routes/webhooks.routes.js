import { Router } from 'express';
import { stripe } from '../config/stripe.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

// NOTE: this route is mounted with express.raw() in index.js — Stripe signature
// verification fails if the body has already been JSON-parsed.
router.post('/stripe', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('[webhook] signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const pi = event.data.object;
        const collaborationId = pi.metadata?.collaboration_id;
        if (collaborationId) {
          await supabaseAdmin.from('collaborations')
            .update({ status: 'funded', funded_at: new Date().toISOString(), stripe_payment_intent_id: pi.id })
            .eq('id', collaborationId);

          await supabaseAdmin.from('transactions').insert({
            collaboration_id: collaborationId,
            type: 'escrow_fund',
            amount: pi.amount / 100,
            currency: pi.currency.toUpperCase(),
            stripe_reference: pi.id,
          });

          const { data: collab } = await supabaseAdmin.from('collaborations').select('creator_id').eq('id', collaborationId).single();
          if (collab) {
            await supabaseAdmin.from('notifications').insert({
              user_id: collab.creator_id, type: 'escrow_funded',
              payload: { collaboration_id: collaborationId },
            });
          }
        }
        break;
      }

      case 'account.updated': {
        const account = event.data.object;
        const userId = account.metadata?.supabase_user_id;
        if (userId) {
          await supabaseAdmin.from('profiles')
            .update({ stripe_connect_onboarded: !!(account.charges_enabled && account.payouts_enabled) })
            .eq('id', userId);
        }
        break;
      }

      case 'charge.refunded': {
        const charge = event.data.object;
        console.log('[webhook] charge refunded:', charge.id);
        break;
      }

      default:
        break; // unhandled event types are fine to ignore
    }
  } catch (err) {
    console.error('[webhook] handler error:', err);
    return res.status(500).send('Webhook handler error');
  }

  res.json({ received: true });
});

export default router;
