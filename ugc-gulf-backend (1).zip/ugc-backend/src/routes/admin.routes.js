import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';
import { refundEscrow, releaseEscrowToCreator } from '../services/stripeService.js';

const router = Router();
router.use(requireAuth, requireRole('admin'));

// Feature 45 — Dedicated Admin Dispute Center
router.get('/disputes', async (req, res) => {
  const { status } = req.query;
  let query = supabaseAdmin.from('disputes').select('*, collaboration:collaborations(*)').order('created_at', { ascending: false });
  if (status) query = query.eq('status', status);
  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.post('/disputes/:id/resolve', async (req, res) => {
  const { resolution, admin_notes } = req.body; // resolution: 'refund' | 'release'
  const { data: dispute } = await supabaseAdmin.from('disputes').select('*, collaboration:collaborations(*)').eq('id', req.params.id).single();
  if (!dispute) return res.status(404).json({ error: 'Not found' });

  try {
    if (resolution === 'refund') {
      await refundEscrow({ paymentIntentId: dispute.collaboration.stripe_payment_intent_id });
      await supabaseAdmin.from('collaborations').update({ status: 'refunded' }).eq('id', dispute.collaboration.id);
      await supabaseAdmin.from('transactions').insert({ collaboration_id: dispute.collaboration.id, type: 'refund', amount: dispute.collaboration.amount, currency: dispute.collaboration.currency });
    } else if (resolution === 'release') {
      const { transfer, feeCents, payoutCents } = await releaseEscrowToCreator({ collaboration: dispute.collaboration });
      await supabaseAdmin.from('collaborations').update({ status: 'released', released_at: new Date().toISOString(), stripe_transfer_id: transfer.id }).eq('id', dispute.collaboration.id);
      await supabaseAdmin.from('transactions').insert([
        { collaboration_id: dispute.collaboration.id, type: 'platform_fee', amount: feeCents / 100, currency: dispute.collaboration.currency },
        { collaboration_id: dispute.collaboration.id, type: 'creator_payout', amount: payoutCents / 100, currency: dispute.collaboration.currency },
      ]);
    } else {
      return res.status(400).json({ error: 'resolution must be "refund" or "release"' });
    }

    const { data, error } = await supabaseAdmin.from('disputes')
      .update({ status: resolution === 'refund' ? 'resolved_refund' : 'resolved_release', admin_notes, resolved_by: req.profile.id, resolved_at: new Date().toISOString() })
      .eq('id', req.params.id).select().single();
    if (error) return res.status(400).json({ error: error.message });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feature 46 — review moderation lives in reviews.routes.js (PATCH /:id/flag, admin-only there too)

// Feature 47 — Commission Settings Control Panel
router.get('/settings', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('platform_settings').select('*');
  if (error) return res.status(400).json({ error: error.message });
  res.json(Object.fromEntries(data.map(s => [s.key, s.value])));
});

router.patch('/settings/:key', async (req, res) => {
  const { value } = req.body;
  const { data, error } = await supabaseAdmin.from('platform_settings')
    .upsert({ key: req.params.key, value, updated_at: new Date().toISOString() }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 48 — User Deactivation & Ban Actions
router.post('/users/:id/ban', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').update({ is_banned: true }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});
router.post('/users/:id/unban', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').update({ is_banned: false }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 52 — approve GCC business license verification
router.post('/users/:id/verify-license', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').update({ business_license_verified: true }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 4 — admin verified-badge stamp
router.post('/users/:id/verify', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('profiles').update({ is_verified: true }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 49 — System-Wide Transaction Ledger
router.get('/ledger', async (req, res) => {
  const { limit = 100 } = req.query;
  const { data, error } = await supabaseAdmin.from('transactions').select('*').order('created_at', { ascending: false }).limit(Number(limit));
  if (error) return res.status(400).json({ error: error.message });

  const totals = data.reduce((acc, t) => {
    acc[t.type] = (acc[t.type] || 0) + Number(t.amount);
    return acc;
  }, {});
  res.json({ transactions: data, totals });
});

// Feature 50 — Global Platform Announcement Bar
router.put('/announcement', async (req, res) => {
  const { active, text } = req.body;
  const { data, error } = await supabaseAdmin.from('platform_settings')
    .upsert({ key: 'announcement', value: { active, text }, updated_at: new Date().toISOString() }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
