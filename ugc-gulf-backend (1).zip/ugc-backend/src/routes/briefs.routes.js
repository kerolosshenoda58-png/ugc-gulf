import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';
import { stripe } from '../config/stripe.js';
import { getOrCreateBrandCustomer } from '../services/stripeService.js';

const router = Router();

// Feature 11 — Advanced Campaign Brief Builder
router.post('/', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { title, description, category, content_goal, platforms, deliverables_count, budget, currency, country, dialect, deadline, requirements_file_url } = req.body;
  if (!title || !budget) return res.status(400).json({ error: 'title and budget are required' });

  const { data, error } = await supabaseAdmin.from('briefs').insert({
    brand_id: req.profile.id, title, description, category, content_goal, platforms,
    deliverables_count, budget, currency, country, dialect, deadline, requirements_file_url,
  }).select().single();

  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// Feature 23 — Bulk-Brief Duplicate Tool
router.post('/:id/duplicate', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { data: original, error: findErr } = await supabaseAdmin.from('briefs').select('*').eq('id', req.params.id).eq('brand_id', req.profile.id).single();
  if (findErr || !original) return res.status(404).json({ error: 'Brief not found' });

  const { id, created_at, updated_at, status, ...rest } = original;
  const { data, error } = await supabaseAdmin.from('briefs').insert({ ...rest, title: `${rest.title} (Copy)`, status: 'open' }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// Feature 57 — Paid "Featured Brief" Upgrade. Charges the brand a flat fee via Stripe,
// then pins the brief for 7 days.
router.post('/:id/feature', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const FEATURE_FEE_USD = 49;
  const { data: brief, error: findErr } = await supabaseAdmin.from('briefs').select('*').eq('id', req.params.id).eq('brand_id', req.profile.id).single();
  if (findErr || !brief) return res.status(404).json({ error: 'Brief not found' });

  try {
    const customerId = await getOrCreateBrandCustomer(req.profile);
    const paymentIntent = await stripe.paymentIntents.create({
      amount: FEATURE_FEE_USD * 100, currency: 'usd', customer: customerId,
      automatic_payment_methods: { enabled: true },
      metadata: { purpose: 'featured_brief', brief_id: brief.id },
    });
    res.json({ clientSecret: paymentIntent.client_secret, amount: FEATURE_FEE_USD });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feature 66 — Campaign Budget Estimator (rough market-rate calculator, not a real query)
router.get('/estimate', async (req, res) => {
  const { budget = 0, category = 'general' } = req.query;
  const AVG_RATE_BY_CATEGORY = { beauty: 280, tech: 340, fashion: 250, fitness: 260, food: 220, home: 240, general: 260 };
  const rate = AVG_RATE_BY_CATEGORY[String(category).toLowerCase()] || AVG_RATE_BY_CATEGORY.general;
  const affordableCreators = Math.max(1, Math.floor(Number(budget) / rate));
  res.json({ estimatedRatePerCreator: rate, affordableCreators });
});

// GET /api/briefs?category=Beauty&country=UAE&status=open
router.get('/', async (req, res) => {
  const { category, country, status = 'open', limit = 50 } = req.query;
  let query = supabaseAdmin.from('briefs').select('*').eq('status', status);
  if (category) query = query.eq('category', category);
  if (country) query = query.eq('country', country);
  query = query.order('is_featured', { ascending: false }).order('created_at', { ascending: false }).limit(Number(limit));

  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

router.get('/:id', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('briefs').select('*').eq('id', req.params.id).single();
  if (error) return res.status(404).json({ error: 'Brief not found' });
  res.json(data);
});

router.patch('/:id', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { data, error } = await supabaseAdmin.from('briefs').update(req.body).eq('id', req.params.id).eq('brand_id', req.profile.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
