import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

router.post('/', requireAuth, async (req, res) => {
  const { collaboration_id, reviewee_id, rating, content } = req.body;
  if (!reviewee_id || !rating) return res.status(400).json({ error: 'reviewee_id and rating are required' });

  const { data, error } = await supabaseAdmin.from('reviews')
    .insert({ collaboration_id, reviewer_id: req.profile.id, reviewee_id, rating, content })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });

  // Recompute the reviewee's rolling average — small dataset assumption is fine at MVP scale.
  const { data: allReviews } = await supabaseAdmin.from('reviews').select('rating').eq('reviewee_id', reviewee_id).eq('is_flagged', false);
  const avg = allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length;
  await supabaseAdmin.from('profiles').update({ rating_avg: Number(avg.toFixed(2)), review_count: allReviews.length }).eq('id', reviewee_id);

  res.status(201).json(data);
});

router.get('/user/:id', async (req, res) => {
  const { data, error } = await supabaseAdmin.from('reviews').select('*').eq('reviewee_id', req.params.id).eq('is_flagged', false).order('created_at', { ascending: false });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Feature 46 — Creator Review Audit Portal (admin moderation)
router.patch('/:id/flag', requireAuth, requireRole('admin'), async (req, res) => {
  const { is_flagged } = req.body;
  const { data, error } = await supabaseAdmin.from('reviews').update({ is_flagged }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
