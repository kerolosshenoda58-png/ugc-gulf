import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

// Feature 64 — Smart Match Score: cheap deterministic overlap score between the
// brief's needs and the creator's profile. Swap for an OPENAI_API_KEY-backed call
// if you want a true semantic match (see services/aiService.js note below).
function computeMatchScore(brief, profile) {
  let score = 40; // baseline
  if (brief.category && profile.niche?.includes(brief.category)) score += 25;
  if (brief.country && profile.country === brief.country) score += 15;
  if (brief.platforms?.some(p => profile.platforms?.includes(p))) score += 10;
  if (profile.rating_avg >= 4.5) score += 10;
  return Math.min(100, score);
}

// Feature 9 — Interactive "Apply with Portfolio" Action
router.post('/', requireAuth, requireRole('creator'), async (req, res) => {
  const { brief_id, package_id, pitch } = req.body;
  if (!brief_id) return res.status(400).json({ error: 'brief_id is required' });

  const { data: brief } = await supabaseAdmin.from('briefs').select('*').eq('id', brief_id).single();
  if (!brief) return res.status(404).json({ error: 'Brief not found' });

  const match_score = computeMatchScore(brief, req.profile);

  const { data, error } = await supabaseAdmin.from('applications')
    .insert({ brief_id, creator_id: req.profile.id, package_id, pitch, match_score })
    .select().single();

  if (error) return res.status(400).json({ error: error.message });

  await supabaseAdmin.from('notifications').insert({
    user_id: brief.brand_id, type: 'new_application', payload: { brief_id, application_id: data.id, creator_id: req.profile.id },
  });

  res.status(201).json(data);
});

// Feature 63 — "Instant Apply" AI Proposal Assistant.
// Requires OPENAI_API_KEY; returns a clear error instead of a fake pitch if unset.
router.post('/draft-pitch', requireAuth, requireRole('creator'), async (req, res) => {
  const { brief_id } = req.body;
  if (!process.env.OPENAI_API_KEY) {
    return res.status(501).json({ error: 'AI proposal assistant requires OPENAI_API_KEY to be configured on the server.' });
  }
  const { data: brief } = await supabaseAdmin.from('briefs').select('*').eq('id', brief_id).single();
  if (!brief) return res.status(404).json({ error: 'Brief not found' });

  try {
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'Write a short, specific 3-sentence creator pitch for a UGC campaign brief. No generic filler.' },
          { role: 'user', content: `Brief: ${brief.title}\n${brief.description}\nCreator niche: ${req.profile.niche?.join(', ')}` },
        ],
      }),
    });
    const json = await resp.json();
    const pitch = json.choices?.[0]?.message?.content;
    if (!pitch) return res.status(502).json({ error: 'AI provider returned no content' });
    res.json({ pitch });
  } catch (err) {
    res.status(502).json({ error: `AI provider error: ${err.message}` });
  }
});

// Feature 65 — Automated Creator Shortlisting
router.get('/brief/:briefId', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('applications')
    .select('*, creator:profiles!applications_creator_id_fkey(*)')
    .eq('brief_id', req.params.briefId)
    .order('match_score', { ascending: false });

  if (error) return res.status(400).json({ error: error.message });

  const tiered = data.map(a => ({
    ...a,
    tier: a.match_score >= 80 && a.creator?.rating_avg >= 4.5 ? 'highly_recommended' : a.match_score >= 60 ? 'good_fit' : 'consider',
  }));
  res.json(tiered);
});

router.patch('/:id', requireAuth, requireRole('brand', 'agency'), async (req, res) => {
  const { status } = req.body;
  const { data, error } = await supabaseAdmin.from('applications').update({ status }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

export default router;
