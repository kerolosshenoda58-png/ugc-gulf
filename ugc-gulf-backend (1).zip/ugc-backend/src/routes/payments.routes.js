import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { getOrCreateCreatorOnboardingLink, getConnectAccountStatus, createExpressPayout } from '../services/stripeService.js';
import { supabaseAdmin } from '../config/supabase.js';

const router = Router();

// Feature 7 — Stripe Express Connect Onboarding
router.post('/connect/onboard', requireAuth, requireRole('creator'), async (req, res) => {
  try {
    const { accountId, url } = await getOrCreateCreatorOnboardingLink(req.profile);
    res.json({ accountId, onboardingUrl: url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/connect/status', requireAuth, requireRole('creator'), async (req, res) => {
  if (!req.profile.stripe_connect_account_id) return res.json({ onboarded: false });
  try {
    const status = await getConnectAccountStatus(req.profile.stripe_connect_account_id);
    res.json({ onboarded: status.charges_enabled && status.payouts_enabled, ...status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feature 60 — Express Payout Workflow (instant cash-out for a 1.5% fee)
router.post('/express-payout', requireAuth, requireRole('creator'), async (req, res) => {
  const { amount } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'amount is required' });
  if (!req.profile.stripe_connect_account_id) return res.status(400).json({ error: 'Complete Stripe onboarding first' });

  try {
    const { payout, extraFeeCents, netCents } = await createExpressPayout({
      stripeConnectAccountId: req.profile.stripe_connect_account_id,
      amountUsd: amount,
    });

    await supabaseAdmin.from('transactions').insert({
      type: 'express_payout_fee', amount: extraFeeCents / 100, currency: 'USD', stripe_reference: payout.id,
    });

    res.json({ payoutId: payout.id, net: netCents / 100, fee: extraFeeCents / 100 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
