import { stripe } from '../config/stripe.js';
import { supabaseAdmin } from '../config/supabase.js';

const COMMISSION_PCT = Number(process.env.PLATFORM_COMMISSION_PCT || 10);
const EXPRESS_FEE_PCT = Number(process.env.EXPRESS_PAYOUT_FEE_PCT || 1.5);

/**
 * Feature 7 — Stripe Express Connect Onboarding.
 * Creates (or reuses) a Stripe Express connected account for a creator and
 * returns a one-time onboarding link.
 */
export async function getOrCreateCreatorOnboardingLink(profile) {
  let accountId = profile.stripe_connect_account_id;

  if (!accountId) {
    const account = await stripe.accounts.create({
      type: 'express',
      email: undefined, // Stripe pulls this from the onboarding flow
      capabilities: { transfers: { requested: true }, card_payments: { requested: true } },
      metadata: { supabase_user_id: profile.id },
    });
    accountId = account.id;

    await supabaseAdmin.from('profiles').update({ stripe_connect_account_id: accountId }).eq('id', profile.id);
  }

  const link = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: process.env.STRIPE_CONNECT_REFRESH_URL,
    return_url: process.env.STRIPE_CONNECT_RETURN_URL,
    type: 'account_onboarding',
  });

  return { accountId, url: link.url };
}

export async function getConnectAccountStatus(accountId) {
  const account = await stripe.accounts.retrieve(accountId);
  return {
    charges_enabled: account.charges_enabled,
    payouts_enabled: account.payouts_enabled,
    details_submitted: account.details_submitted,
  };
}

/**
 * Feature 31 — Three-Step Stripe Escrow Release, step 1: fund.
 * Charges the brand's card and holds the funds in the PLATFORM's Stripe balance
 * (no `transfer_data.destination` here — that's what makes it an escrow hold
 * rather than an instant pass-through payment). Funds only move to the creator
 * in `releaseEscrowToCreator` once the brand approves.
 */
export async function createEscrowPaymentIntent({ collaborationId, amountUsd, brandStripeCustomerId, currency = 'usd' }) {
  const amountCents = Math.round(amountUsd * 100);

  const paymentIntent = await stripe.paymentIntents.create({
    amount: amountCents,
    currency,
    customer: brandStripeCustomerId || undefined,
    capture_method: 'automatic',
    metadata: { collaboration_id: collaborationId, purpose: 'escrow_fund' },
    automatic_payment_methods: { enabled: true },
  });

  return paymentIntent;
}

/**
 * Feature 31/34 — release escrow to the creator once the brand approves,
 * automatically deducting the platform commission (Feature 34).
 */
export async function releaseEscrowToCreator({ collaboration }) {
  const { data: creator } = await supabaseAdmin
    .from('profiles')
    .select('stripe_connect_account_id, stripe_connect_onboarded')
    .eq('id', collaboration.creator_id)
    .single();

  if (!creator?.stripe_connect_account_id || !creator.stripe_connect_onboarded) {
    throw new Error('Creator has not completed Stripe Connect onboarding — cannot release funds');
  }

  const totalCents = Math.round(Number(collaboration.amount) * 100);
  const feeCents = Math.round(totalCents * (COMMISSION_PCT / 100));
  const payoutCents = totalCents - feeCents;

  const transfer = await stripe.transfers.create({
    amount: payoutCents,
    currency: (collaboration.currency || 'USD').toLowerCase(),
    destination: creator.stripe_connect_account_id,
    source_transaction: undefined, // funds already captured to platform balance via the PaymentIntent
    metadata: { collaboration_id: collaboration.id },
  });

  return { transfer, feeCents, payoutCents };
}

/**
 * Feature 60 — Express Payout Workflow: creator cashes out immediately for
 * a small extra fee instead of waiting for Stripe's standard payout schedule.
 */
export async function createExpressPayout({ stripeConnectAccountId, amountUsd }) {
  const grossCents = Math.round(amountUsd * 100);
  const extraFeeCents = Math.round(grossCents * (EXPRESS_FEE_PCT / 100));
  const netCents = grossCents - extraFeeCents;

  const payout = await stripe.payouts.create(
    { amount: netCents, currency: 'usd', method: 'instant' },
    { stripeAccount: stripeConnectAccountId }
  );

  return { payout, extraFeeCents, netCents };
}

/** Feature 59 — dispute resolution refund path. */
export async function refundEscrow({ paymentIntentId }) {
  return stripe.refunds.create({ payment_intent: paymentIntentId });
}

/** Feature 15 — creates/reuses a Stripe Customer for a brand so future charges are faster. */
export async function getOrCreateBrandCustomer(profile) {
  if (profile.stripe_customer_id) return profile.stripe_customer_id;

  const customer = await stripe.customers.create({
    name: profile.company_name || profile.full_name,
    metadata: { supabase_user_id: profile.id },
  });

  await supabaseAdmin.from('profiles').update({ stripe_customer_id: customer.id }).eq('id', profile.id);
  return customer.id;
}
