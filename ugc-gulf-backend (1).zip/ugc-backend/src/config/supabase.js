import { createClient } from '@supabase/supabase-js';

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
  console.warn('[config] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are not set — API calls will fail until .env is configured.');
}

// Service-role client: used by the backend for privileged writes (e.g. releasing escrow).
// This bypasses Row Level Security, so it must NEVER be exposed to the frontend.
export const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

// Anon client: only used to verify a user's JWT on incoming requests.
export const supabaseAnon = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);
