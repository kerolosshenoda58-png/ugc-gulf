import { supabaseAnon, supabaseAdmin } from '../config/supabase.js';

/**
 * Verifies the Bearer token issued by Supabase Auth (sent by the frontend after
 * supabase.auth.signInWithPassword / signInWithOtp), attaches req.user and req.profile.
 */
export async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing bearer token' });

  const { data, error } = await supabaseAnon.auth.getUser(token);
  if (error || !data?.user) return res.status(401).json({ error: 'Invalid or expired session' });

  const { data: profile, error: profileError } = await supabaseAdmin
    .from('profiles')
    .select('*')
    .eq('id', data.user.id)
    .single();

  if (profileError || !profile) return res.status(403).json({ error: 'No profile found for this account' });
  if (profile.is_banned) return res.status(403).json({ error: 'This account has been suspended' });

  req.user = data.user;
  req.profile = profile;
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.profile || !roles.includes(req.profile.role)) {
      return res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });
    }
    next();
  };
}
