import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import { FileText, Plus, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TEMPLATES = [
  { title: 'Standard UGC Video Agreement', desc: 'Basic agreement for single-video UGC content with usage rights.', category: 'UGC' },
  { title: 'Multi-Video Campaign Contract', desc: 'For campaigns requiring multiple videos across platforms.', category: 'Campaign' },
  { title: 'Brand Ambassador Agreement', desc: 'Long-term ambassador partnership with exclusivity terms.', category: 'Ambassador' },
  { title: 'One-Time Usage License', desc: 'Single-use content license for ads or social media.', category: 'License' },
  { title: 'Product Review Agreement', desc: 'For sponsored product review content with disclosure terms.', category: 'Review' },
  { title: 'Influencer Collaboration Contract', desc: 'Full influencer partnership with deliverables and metrics.', category: 'Influencer' },
];

export default function ContractTemplates() {
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const data = await base44.entities.Contract.list('-created_date', 20);
      setContracts(data || []);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <AppLayout><div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" /></div></AppLayout>;

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6">
          <FileText className="w-5 h-5 text-violet-500" />
          <h1 className="text-2xl font-bold">Contract Templates</h1>
        </div>

        <h3 className="font-semibold text-sm mb-3">Standard Templates</h3>
        <div className="grid sm:grid-cols-2 gap-3 mb-8">
          {TEMPLATES.map((t, i) => (
            <div key={i} className="bg-card rounded-2xl border border-border p-4 card-shadow hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-violet-100 dark:bg-violet-950 flex items-center justify-center flex-shrink-0"><FileText className="w-5 h-5 text-violet-600" /></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2"><p className="text-sm font-medium">{t.title}</p><span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-secondary text-muted-foreground flex-shrink-0">{t.category}</span></div>
                  <p className="text-xs text-muted-foreground mt-1">{t.desc}</p>
                  <button className="flex items-center gap-1 text-xs text-primary hover:underline mt-2">Use template <ArrowRight className="w-3 h-3" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <h3 className="font-semibold text-sm mb-3">Your Contracts</h3>
        {contracts.length === 0 ? (
          <div className="bg-card rounded-2xl border border-border p-8 text-center card-shadow">
            <FileText className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground mb-3">No contracts created yet</p>
            <Button className="bg-primary"><Plus className="w-4 h-4 mr-1" /> New Contract</Button>
          </div>
        ) : (
          <div className="space-y-2">
            {contracts.map(c => (
              <div key={c.id} className="bg-card rounded-2xl border border-border p-4 card-shadow flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-violet-100 dark:bg-violet-950 flex items-center justify-center flex-shrink-0"><FileText className="w-4 h-4 text-violet-600" /></div>
                <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{c.title}</p><p className="text-xs text-muted-foreground">{c.brand_name} · ${c.total_amount}</p></div>
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full capitalize ${c.status === 'fully_signed' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{c.status.replace(/_/g, ' ')}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
