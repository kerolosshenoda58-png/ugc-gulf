import React, { useState, useEffect, useCallback } from 'react';
import { Trophy, Crown, Star, Zap, TrendingUp, Award } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import { LEVELS } from '@/lib/constants';
import { Link } from 'react-router-dom';

export default function Leaderboard() {
  const [creators, setCreators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('all');

  const fetchData = useCallback(async () => {
    try {
      const data = await base44.entities.Profile.filter({ user_type: 'creator' }, '-xp_points', 50);
      setCreators(data || []);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin"></div>
        </div>
      </AppLayout>
    );
  }

  const top3 = creators.slice(0, 3);
  const rest = creators.slice(3);
  const podiumOrder = [top3[1], top3[0], top3[2]].filter(Boolean);
  const podiumStyles = [
    { height: 'h-28', medal: '🥈', gradient: 'from-slate-400 to-slate-600', ring: 'ring-slate-300' },
    { height: 'h-36', medal: '🥇', gradient: 'from-yellow-400 to-amber-500', ring: 'ring-yellow-400' },
    { height: 'h-24', medal: '🥉', gradient: 'from-orange-400 to-amber-700', ring: 'ring-orange-400' },
  ];

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-1">
          <Trophy className="w-5 h-5 text-yellow-400 fill-yellow-400" />
          <h1 className="text-2xl font-bold">Creator Leaderboard</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-6">Top creators ranked by XP, activity, and community engagement</p>

        {top3.length > 0 && (
          <div className="flex items-end justify-center gap-3 mb-8">
            {podiumOrder.map((creator, i) => {
              const level = LEVELS[creator?.level || 'bronze'];
              return (
                <Link key={creator?.id || i} to={`/profile/${creator?.id}`} className="flex flex-col items-center" style={{ width: '30%' }}>
                  <div className="text-2xl mb-1">{podiumStyles[i].medal}</div>
                  {creator?.profile_photo_url ? (
                    <img src={creator.profile_photo_url} alt="" className={`w-16 h-16 rounded-full object-cover ring-4 ${podiumStyles[i].ring}`} />
                  ) : (
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${podiumStyles[i].gradient} flex items-center justify-center text-white text-xl font-bold ring-4 ${podiumStyles[i].ring}`}>
                      {creator?.full_name?.[0]?.toUpperCase()}
                    </div>
                  )}
                  <p className="font-semibold text-sm mt-2 truncate w-full text-center">{creator?.full_name}</p>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full bg-gradient-to-r ${level?.color || 'from-amber-700 to-amber-900'} text-white capitalize`}>
                    {level?.label || 'Bronze'}
                  </span>
                  <div className={`w-full ${podiumStyles[i].height} bg-gradient-to-br ${podiumStyles[i].gradient} rounded-t-2xl mt-2 flex items-center justify-center`}>
                    <span className="text-white font-bold text-2xl">{creator?.xp_points || 0}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        <div className="space-y-2">
          {rest.length === 0 && top3.length === 0 ? (
            <div className="bg-white rounded-2xl border border-border p-8 text-center">
              <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No creators yet</p>
            </div>
          ) : (
            rest.map((c, i) => {
              const level = LEVELS[c.level || 'bronze'];
              return (
                <Link
                  key={c.id}
                  to={`/profile/${c.id}`}
                  className="bg-white rounded-2xl border border-border p-3 flex items-center gap-3 card-shadow hover:border-primary/30 transition-all"
                >
                  <span className="text-sm font-bold text-muted-foreground w-6 text-center">{i + 4}</span>
                  {c.profile_photo_url ? (
                    <img src={c.profile_photo_url} alt="" className="w-10 h-10 rounded-full object-cover" />
                  ) : (
                    <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-white text-sm font-bold">
                      {c.full_name?.[0]?.toUpperCase()}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{c.full_name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{c.creator_type?.replace('_', ' ')}</p>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      {(c.rating_avg || 0).toFixed(1)}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full bg-gradient-to-r ${level?.color || 'from-amber-700 to-amber-900'} text-white text-[10px] font-bold capitalize`}>
                      {level?.label || 'Bronze'}
                    </span>
                    <span className="flex items-center gap-1 font-bold text-primary">
                      <Zap className="w-3 h-3" />
                      {c.xp_points || 0}
                    </span>
                  </div>
                </Link>
              );
            })
          )}
        </div>
      </div>
    </AppLayout>
  );
}
