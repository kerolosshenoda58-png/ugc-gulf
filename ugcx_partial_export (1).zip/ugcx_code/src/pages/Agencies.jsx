import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Building2, Search, MapPin, Users, Globe, Star } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import { Link } from 'react-router-dom';
import { COUNTRIES } from '@/lib/constants';

export default function Agencies() {
  const [agencies, setAgencies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [country, setCountry] = useState('all');

  const fetchData = useCallback(async () => {
    try {
      const data = await base44.entities.Profile.filter({ user_type: 'agency' }, '-rating_avg', 50);
      setAgencies(data || []);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = useMemo(() => {
    let result = agencies;
    if (country !== 'all') result = result.filter(a => a.country === country);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(a => a.full_name?.toLowerCase().includes(q) || a.bio?.toLowerCase().includes(q) || a.industries?.some(i => i.toLowerCase().includes(q)));
    }
    return result;
  }, [agencies, search, country]);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin"></div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-1">
          <Building2 className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold">Agency Partnerships</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-6">Browse partner agencies and talent management firms</p>

        <div className="flex flex-col sm:flex-row gap-2 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search agencies by name, industry..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border bg-white text-sm focus-visible:ring-1 focus-visible:ring-primary outline-none"
            />
          </div>
          <select
            value={country}
            onChange={e => setCountry(e.target.value)}
            className="border border-border rounded-xl px-3 py-2.5 text-sm bg-white focus-visible:ring-1 focus-visible:ring-primary outline-none"
          >
            <option value="all">All Countries</option>
            {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-border p-8 text-center">
            <Building2 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No agencies found. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map(a => (
              <Link key={a.id} to={`/profile/${a.id}`} className="bg-white rounded-2xl border border-border p-4 card-shadow hover:border-primary/30 transition-all">
                <div className="flex items-start gap-3">
                  {a.profile_photo_url ? (
                    <img src={a.profile_photo_url} alt="" className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-white text-lg font-bold flex-shrink-0">
                      {a.full_name?.[0]?.toUpperCase()}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <p className="font-semibold text-sm truncate">{a.full_name}</p>
                      {a.is_verified && <Star className="w-3.5 h-3.5 text-primary fill-primary flex-shrink-0" />}
                    </div>
                    {a.bio && <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{a.bio}</p>}
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      {a.country && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{a.country}</span>}
                      {a.employee_count && <span className="flex items-center gap-0.5"><Users className="w-3 h-3" />{a.employee_count}</span>}
                      {a.rating_avg > 0 && <span className="flex items-center gap-0.5"><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />{a.rating_avg.toFixed(1)}</span>}
                    </div>
                    {a.industries?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {a.industries.slice(0, 3).map((ind, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground">{ind}</span>)}
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
