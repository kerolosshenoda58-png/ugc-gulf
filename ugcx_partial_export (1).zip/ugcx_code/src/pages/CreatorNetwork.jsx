import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Users, Search, MapPin, Star, Zap, MessageSquare, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import { Link } from 'react-router-dom';
import { COUNTRIES, CREATOR_TYPES, SKILLS } from '@/lib/constants';

export default function CreatorNetwork() {
  const [creators, setCreators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [skillFilter, setSkillFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [countryFilter, setCountryFilter] = useState('all');

  const fetchData = useCallback(async () => {
    try {
      const data = await base44.entities.Profile.filter({ user_type: 'creator' }, '-xp_points', 50);
      setCreators(data || []);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = useMemo(() => {
    let result = creators;
    if (typeFilter !== 'all') result = result.filter(c => c.creator_type === typeFilter);
    if (countryFilter !== 'all') result = result.filter(c => c.country === countryFilter);
    if (skillFilter !== 'all') result = result.filter(c => c.skills?.includes(skillFilter));
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(c =>
        c.full_name?.toLowerCase().includes(q) ||
        c.bio?.toLowerCase().includes(q) ||
        c.skills?.some(s => s.toLowerCase().includes(q)) ||
        c.industries?.some(i => i.toLowerCase().includes(q))
      );
    }
    return result;
  }, [creators, search, skillFilter, typeFilter, countryFilter]);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin"></div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-1">
          <Users className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold">Creator Network</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-6">Connect with creators based on skills, location, and creative interests</p>

        <div className="space-y-2 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, skill, or industry..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border bg-white text-sm focus-visible:ring-1 focus-visible:ring-primary outline-none"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="border border-border rounded-xl px-3 py-2.5 text-sm bg-white capitalize focus-visible:ring-1 focus-visible:ring-primary outline-none">
              <option value="all">All Creator Types</option>
              {CREATOR_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
            <select value={skillFilter} onChange={e => setSkillFilter(e.target.value)} className="border border-border rounded-xl px-3 py-2.5 text-sm bg-white focus-visible:ring-1 focus-visible:ring-primary outline-none">
              <option value="all">All Skills</option>
              {SKILLS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={countryFilter} onChange={e => setCountryFilter(e.target.value)} className="border border-border rounded-xl px-3 py-2.5 text-sm bg-white focus-visible:ring-1 focus-visible:ring-primary outline-none">
              <option value="all">All Countries</option>
              {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <p className="text-xs text-muted-foreground mb-3">{filtered.length} creators found</p>

        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-border p-8 text-center">
            <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No creators match your filters. Try broadening your search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map(c => (
              <div key={c.id} className="bg-white rounded-2xl border border-border p-4 card-shadow hover:border-primary/30 transition-all">
                <div className="flex items-start gap-3">
                  <Link to={`/profile/${c.id}`} className="flex-shrink-0">
                    {c.profile_photo_url ? (
                      <img src={c.profile_photo_url} alt="" className="w-12 h-12 rounded-full object-cover ring-2 ring-primary/10" />
                    ) : (
                      <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-white text-lg font-bold">
                        {c.full_name?.[0]?.toUpperCase()}
                      </div>
                    )}
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/profile/${c.id}`} className="font-semibold text-sm hover:text-primary transition-colors truncate block">
                      {c.full_name}
                    </Link>
                    <p className="text-xs text-muted-foreground capitalize">{c.creator_type?.replace('_', ' ')}</p>
                    <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                      {c.country && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{c.country}</span>}
                      {c.rating_avg > 0 && <span className="flex items-center gap-0.5"><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />{c.rating_avg.toFixed(1)}</span>}
                      <span className="flex items-center gap-0.5"><Zap className="w-3 h-3 text-primary" />{c.xp_points || 0}</span>
                    </div>
                  </div>
                  <Link to="/messages" className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-primary hover:text-white transition-colors">
                    <MessageSquare className="w-4 h-4" />
                  </Link>
                </div>
                {c.bio && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.bio}</p>}
                {c.skills?.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {c.skills.slice(0, 3).map((s, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground">{s}</span>)}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
