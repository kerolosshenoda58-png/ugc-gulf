import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Users, Hash, Flame, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import CreatePost from '@/components/feed/CreatePost';
import PostCard from '@/components/feed/PostCard';
import { POST_TYPES } from '@/lib/constants';

const TOPIC_GRADIENTS = [
  'from-primary to-accent',
  'from-accent to-primary',
  'from-primary to-accent',
  'from-accent to-primary',
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 24 } },
};

export default function Community() {
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTopic, setActiveTopic] = useState(null);

  const fetchProfile = useCallback(async () => {
    try {
      const user = await base44.auth.me();
      const profiles = await base44.entities.Profile.filter({ created_by_id: user.id });
      if (profiles?.length > 0) setProfile(profiles[0]);
    } catch (e) {}
  }, []);

  const fetchPosts = useCallback(async () => {
    try {
      const communityTypes = POST_TYPES.filter(t => ['marketing_tip', 'case_study', 'before_after', 'collaboration', 'hiring', 'ugc_inspiration'].includes(t.value)).map(t => t.value);
      const data = await base44.entities.Post.list('-created_date', 50);
      const filtered = (data || []).filter(p => !p.post_type || p.post_type === 'general' || communityTypes.includes(p.post_type));
      setPosts(filtered);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchProfile();
    fetchPosts();
  }, []);

  const topicCounts = useMemo(() => {
    const counts = {};
    posts.forEach(p => {
      if (p.post_type && p.post_type !== 'general') {
        counts[p.post_type] = (counts[p.post_type] || 0) + 1;
      }
    });
    return counts;
  }, [posts]);

  const displayedPosts = useMemo(() => {
    if (!activeTopic) return posts;
    return posts.filter(p => p.post_type === activeTopic || (!activeTopic && (!p.post_type || p.post_type === 'general')));
  }, [posts, activeTopic]);

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-5">
          <Users className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold">Community</h1>
        </div>

        {/* Topic chips */}
        <div className="mb-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Flame className="w-3.5 h-3.5 text-accent" />
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Topics</h3>
          </div>
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
            <button
              onClick={() => setActiveTopic(null)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                !activeTopic ? 'bg-gradient-to-r from-primary to-accent text-white border-transparent shadow-md' : 'bg-white text-muted-foreground border-border hover:border-primary/30'
              }`}
            >
              <Hash className="w-3.5 h-3.5" /> All
            </button>
            {POST_TYPES.filter(t => ['marketing_tip', 'case_study', 'before_after', 'collaboration', 'hiring', 'ugc_inspiration'].includes(t.value)).map((topic, i) => (
              <button
                key={topic.value}
                onClick={() => setActiveTopic(topic.value)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                  activeTopic === topic.value ? `bg-gradient-to-r ${TOPIC_GRADIENTS[i % TOPIC_GRADIENTS.length]} text-white border-transparent shadow-md` : 'bg-white text-muted-foreground border-border hover:border-primary/30'
                }`}
              >
                <Hash className="w-3.5 h-3.5" /> {topic.label}
                {topicCounts[topic.value] > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${activeTopic === topic.value ? 'bg-white/25' : 'bg-secondary'}`}>
                    {topicCounts[topic.value]}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Create Post */}
        {profile && (
          <div className="mb-4">
            <CreatePost profile={profile} onPostCreated={fetchPosts} />
          </div>
        )}

        {/* Posts */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
          </div>
        ) : displayedPosts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-border card-shadow p-8 text-center">
            <div className="w-16 h-16 rounded-2xl gradient-vibrant flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-1">No posts yet</h3>
            <p className="text-sm text-muted-foreground">Be the first to share something with the community!</p>
          </div>
        ) : (
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
            {displayedPosts.map(post => (
              <motion.div key={post.id} variants={itemVariants}>
                <PostCard post={post} currentUser={profile} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
}
