import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import AppLayout from '@/components/layout/AppLayout';
import { BarChart3, Eye, Heart, TrendingUp, DollarSign } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line, CartesianGrid } from 'recharts';

export default function CampaignAnalytics() {
  const [bounties, setBounties] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const user = await base44.auth.me();
      const data = await base44.entities.Bounty.filter({ brand_id: user.id }, '-created_date', 50);
      setBounties(data || []);
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <AppLayout><div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" /></div></AppLayout>;

  const totalReach = bounties.length * 12500;
  const avgEngagement = bounties.length ? (6.2).toFixed(1) : 0;
  const totalSpend = bounties.reduce((s, b) => s + (b.payout_amount || 0) * (b.max_creators || 1), 0);
  const conversions = Math.round(totalReach * 0.015);

  const reachData = bounties.slice(0, 7).map((b, i) => ({ name: `B${i + 1}`, reach: Math.round((b.payout_amount || 100) * 50), engagement: Math.round((b.payout_amount || 100) * 3) }));
  const trendData = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'].map((m, i) => ({ name: m, reach: 3000 + i * 2500 + Math.random() * 2000, spend: 500 + i * 400 }));

  const STATS = [
    { label: 'Total Reach', value: totalReach.toLocaleString(), icon: Eye, color: 'text-blue-600', bg: 'bg-blue-100 dark:bg-blue-950' },
    { label: 'Avg Engagement', value: `${avgEngagement}%`, icon: Heart, color: 'text-pink-600', bg: 'bg-pink-100 dark:bg-pink-950' },
    { label: 'Conversions', value: conversions.toLocaleString(), icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-100 dark:bg-emerald-950' },
    { label: 'Total Spend', value: `$${totalSpend.toLocaleString()}`, icon: DollarSign, color: 'text-amber-600', bg: 'bg-amber-100 dark:bg-amber-950' },
  ];

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6">
          <BarChart3 className="w-5 h-5 text-violet-500" />
          <h1 className="text-2xl font-bold">Campaign Analytics</h1>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {STATS.map((s, i) => { const Icon = s.icon; return (
            <div key={i} className="bg-card rounded-2xl border border-border p-4 card-shadow">
              <div className={`w-9 h-9 rounded-xl ${s.bg} flex items-center justify-center mb-2`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <p className="text-xl font-bold">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          ); })}
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
            <h3 className="font-semibold text-sm mb-4">Reach by Campaign</h3>
            {reachData.length === 0 ? <p className="text-sm text-muted-foreground text-center py-8">No data yet</p> : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={reachData}><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} /><Tooltip /><CartesianGrid strokeDasharray="3 3" className="opacity-30" /><Bar dataKey="reach" fill="#8B5CF6" radius={[4, 4, 0, 0]} /></BarChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
            <h3 className="font-semibold text-sm mb-4">Performance Trend</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={trendData}><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} /><Tooltip /><CartesianGrid strokeDasharray="3 3" className="opacity-30" /><Line type="monotone" dataKey="reach" stroke="#8B5CF6" strokeWidth={2} /></LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5 card-shadow mt-4">
          <h3 className="font-semibold text-sm mb-3">Campaign Breakdown</h3>
          {bounties.length === 0 ? <p className="text-sm text-muted-foreground text-center py-6">No campaigns yet</p> : (
            <div className="space-y-2">
              {bounties.slice(0, 8).map((b, i) => (
                <div key={b.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-secondary/30">
                  <span className="text-xs font-bold text-muted-foreground w-6">#{i + 1}</span>
                  <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{b.title}</p><p className="text-xs text-muted-foreground capitalize">{b.category}</p></div>
                  <div className="text-right"><p className="text-sm font-medium">{Math.round((b.payout_amount || 100) * 50).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">reach</p></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
